local l = (bl and 1) or -1
local d = (bl and 1) or -0.8

local items = {
  "minecraft:orange_bed",
  "minecraft:white_bed",
  "minecraft:light_gray_bed",
  "minecraft:gray_bed",
  "minecraft:black_bed",
  "minecraft:brown_bed",
  "minecraft:red_bed",
  "minecraft:yellow_bed",
  "minecraft:lime_bed",
  "minecraft:green_bed",
  "minecraft:cyan_bed",
  "minecraft:light_blue_bed",
  "minecraft:blue_bed",
  "minecraft:purple_bed",
  "minecraft:magenta_bed",
  "minecraft:pink_bed"
}

for i, id in pairs(items) do
    if I:isOf(item, Items:get(id)) then
        renderAsBlock:put(id, false)
    M:scale(matrices,1,1,1)
        M:rotateX(matrices, -55)
        M:rotateY(matrices, -37*d)
    M:rotateZ(matrices, -60*l)
        M:moveX(matrices, 0.4*l)
    M:moveZ(matrices, 0.4)
	M:moveY(matrices, -0.3)
    end
end